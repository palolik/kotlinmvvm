package com.example.easyfood;

import android.app.Activity;

public class YourActivityName extends Activity {
}
